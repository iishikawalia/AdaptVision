export const STAGES = ['Collect', 'Analyze', 'Declare', 'Discuss', 'Reveal', 'Fix', 'Retrain', 'Test', 'Fair test'];

export default function Progress({ at, round }) {
  return (
    <ol className="progress" aria-label="Lesson steps">
      {STAGES.map((s, i) => (
        <li key={s} className={i < at ? 'done' : i === at ? 'now' : ''} aria-current={i === at ? 'step' : undefined}>
          <span className="box">{i < at ? '✓' : i + 1}</span>{s}
        </li>
      ))}
      {round > 1 && <li className="round">Round {round}</li>}
    </ol>
  );
}
