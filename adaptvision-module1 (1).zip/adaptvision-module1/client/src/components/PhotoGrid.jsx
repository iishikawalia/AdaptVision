// A grid of lesson photos. Optional per-photo marks (highlighter tags) and selection.
export function photoSrc(photo, clean) {
  return `/photos/${clean ? photo.clean : photo.img}`;
}

export default function PhotoGrid({ photos, clean, selected, onToggle, marks, big, wipe }) {
  return (
    <ul className={`grid ${big ? 'big' : ''}`}>
      {photos.map((p, i) => {
        const isSel = selected?.includes(p.id);
        const mark = marks?.[i];
        const inner = (
          <>
            <span className={`frame ${wipe ? 'wipe' : ''}`}>
              <img src={photoSrc(p, false)} alt="" loading="lazy" />
              <img className={`cleaned ${clean ? 'show' : ''}`} src={photoSrc(p, true)} alt="" loading="lazy" />
            </span>
            {mark !== undefined && (
              <span className={`tag ${mark.on ? 'on' : ''}`}>{mark.text}</span>
            )}
            {isSel && <span className="tick" aria-hidden>✓</span>}
          </>
        );
        return (
          <li key={p.id}>
            {onToggle ? (
              <button type="button" className={`photo ${isSel ? 'sel' : ''}`} aria-pressed={isSel}
                aria-label={`Photo ${i + 1}${isSel ? ', chosen' : ''}`} onClick={() => onToggle(p.id)}>
                {inner}
              </button>
            ) : (
              <div className="photo" role="img" aria-label={`Photo ${i + 1}`}>{inner}</div>
            )}
          </li>
        );
      })}
    </ul>
  );
}
