// Matty: a small robot built from a pen cap. Moods drive eyes, brows and mouth.
const EYES = {
  happy: <><circle cx="44" cy="58" r="6" /><circle cx="76" cy="58" r="6" /></>,
  thinking: <><circle cx="47" cy="54" r="6" /><circle cx="79" cy="54" r="6" /></>,
  confident: <><path d="M36 58h16M68 58h16" strokeWidth="6" strokeLinecap="round" /></>,
  confused: <><circle cx="44" cy="58" r="7" /><circle cx="76" cy="60" r="4" /></>,
  proud: <><path d="M37 60q7-9 14 0M69 60q7-9 14 0" strokeWidth="5" fill="none" strokeLinecap="round" /></>,
  sad: <><circle cx="44" cy="60" r="5" /><circle cx="76" cy="60" r="5" /></>,
};
const MOUTH = {
  happy: 'M48 78q12 10 24 0',
  thinking: 'M52 80h16',
  confident: 'M46 76q14 12 28-2',
  confused: 'M50 82q5-6 10 0t10 0',
  proud: 'M44 75q16 16 32 0',
  sad: 'M48 84q12-9 24 0',
};

export default function Matty({ mood = 'happy', size = 112 }) {
  return (
    <svg className={`matty-svg mood-${mood}`} width={size} height={size * 1.25} viewBox="0 0 120 150" role="img" aria-label={`Matty looks ${mood}`}>
      {/* antenna = pen clip */}
      <rect x="57" y="4" width="6" height="22" rx="3" fill="var(--steel)" />
      <circle cx="60" cy="6" r="6" fill={mood === 'thinking' ? 'var(--highlight)' : 'var(--redpen)'} className="matty-bulb" />
      {/* head = pen cap */}
      <rect x="14" y="24" width="92" height="76" rx="26" fill="var(--ink)" />
      <rect x="24" y="36" width="72" height="54" rx="18" fill="var(--paper)" />
      <g fill="var(--graphite)" stroke="var(--graphite)">{EYES[mood] || EYES.happy}</g>
      {mood === 'confused' && <path d="M34 44l16 4M86 46l-14 2" stroke="var(--graphite)" strokeWidth="4" strokeLinecap="round" />}
      <path d={MOUTH[mood] || MOUTH.happy} stroke="var(--graphite)" strokeWidth="4" fill="none" strokeLinecap="round" />
      {/* body = barrel + nib */}
      <rect x="36" y="102" width="48" height="30" rx="8" fill="var(--ink-2)" />
      <path d="M44 132h32l-16 16z" fill="var(--steel)" />
    </svg>
  );
}

// Matty plus a speech card. Speech is in Matty's handwriting.
export function MattySays({ mood, children, small }) {
  return (
    <div className={`matty ${small ? 'small' : ''}`}>
      <Matty mood={mood} size={small ? 72 : 104} />
      <div className="speech" aria-live="polite">{children}</div>
    </div>
  );
}
