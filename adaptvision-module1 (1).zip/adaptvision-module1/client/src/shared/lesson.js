// Lesson rules shared by the browser, the API server and the prep script.
// Pure JS only (no React, no Node APIs) so all three can import it.

export const OBJECTS = {
  pen: { id: 'pen', label: 'Pen', ready: true },
  eraser: { id: 'eraser', label: 'Eraser', ready: false },
  marker: { id: 'marker', label: 'Marker', ready: false },
};

export const MIN_TRAIN = 3;   // photos needed before Matty can study
export const MAX_ROUNDS = 2;  // round 1 = background, round 2 = cap (in the pilot pool)

// Matty "relies on" a shortcut when it appears in at least this share of the
// training photos. Computed from the model's per-photo answers, never from a
// self-reported confidence score.
export const SHORTCUT_SHARE = 0.75;

export function shareOf(hasFeature) {
  if (!hasFeature?.length) return 0;
  return hasFeature.filter(Boolean).length / hasFeature.length;
}

export function finishAnalysis(raw, ids) {
  const share = shareOf(raw.hasFeature);
  return { ...raw, ids, share, reliesOnShortcut: share >= SHORTCUT_SHARE };
}

// How many new photos a pair must add in the "more variety" fix.
export function minToAdd(trainCount) {
  return Math.max(2, Math.ceil(trainCount / 2));
}

// Which fix a shortcut calls for. A background can be erased (preprocessing);
// a property of the object itself, like a cap, can only be fixed with variety.
export function fixFor(analysis, applied) {
  const wanted = analysis.featureKind === 'surroundings' ? 'clean' : 'diversify';
  if (!applied[wanted]) return wanted;
  const other = wanted === 'clean' ? 'diversify' : 'clean';
  return applied[other] ? null : other;
}

// Matty's working rule after a round of study.
export function ruleFrom(analysis) {
  if (analysis.reliesOnShortcut) {
    return { kind: 'shortcut', featureLabel: analysis.featureLabel, statement: analysis.mattyRule };
  }
  return { kind: 'object', statement: analysis.objectRule };
}

// Keys for the Tier 2 pre-analyzed pool. Tier 2 has a fixed photo set, so the
// only thing that varies is which fixes have been applied.
export function stateKey({ clean, diverse }) {
  return `clean=${clean ? 1 : 0}|diverse=${diverse ? 1 : 0}`;
}
export function testKey(state, photoId) {
  return `${stateKey(state)}|${photoId}`;
}
