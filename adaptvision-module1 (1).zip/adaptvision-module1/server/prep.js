// npm run prep          resize photos, erase backgrounds, AND pre-analyze the Tier 2 pool (needs key)
// npm run prep:images   only the photo steps (runs automatically on `npm start`, no API calls)
// npm run prep:mock     photo steps + a SIMULATED Tier 2 file, for rehearsal without a key
import fs from 'node:fs';
import path from 'node:path';
import sharp from 'sharp';
import { CONFIG, PATHS, mode } from './lib/config.js';
import { eraseBackground } from './lib/clean.js';
import { stateKey, testKey, ruleFrom } from '../client/src/shared/lesson.js';

const args = new Set(process.argv.slice(2));
const OBJECT_TYPE = 'pen';
const GROUPS = ['train', 'diverse', 'heldout'];
const MAX_SIDE = 768; // keeps each API call small and fast on classroom Wi-Fi
const EXT = /\.(jpe?g|png|webp|heic|heif|tiff?)$/i;

async function prepareImages() {
  for (const d of ['img', 'clean']) fs.mkdirSync(path.join(PATHS.photos, d), { recursive: true });
  const photos = [];
  for (const group of GROUPS) {
    const dir = path.join(PATHS.source, group);
    if (!fs.existsSync(dir)) continue;
    const files = fs.readdirSync(dir).filter((f) => EXT.test(f) && !/\.clean\./i.test(f)).sort();
    for (const file of files) {
      const stem = file.replace(EXT, '');
      const id = `${group}-${stem}`.toLowerCase().replace(/[^a-z0-9-]+/g, '-');
      const src = path.join(dir, file);
      const img = `img/${id}.jpg`;
      const clean = `clean/${id}.jpg`;
      const outImg = path.join(PATHS.photos, img);
      const outClean = path.join(PATHS.photos, clean);
      const manual = fs.readdirSync(dir).find((f) => f.toLowerCase().startsWith(`${stem.toLowerCase()}.clean.`));
      const newest = Math.max(fs.statSync(src).mtimeMs, manual ? fs.statSync(path.join(dir, manual)).mtimeMs : 0);
      const upToDate = fs.existsSync(outImg) && fs.existsSync(outClean) && fs.statSync(outClean).mtimeMs >= newest;

      let cleanOk = true;
      if (!upToDate) {
        try {
          const base = sharp(src).rotate().resize(MAX_SIDE, MAX_SIDE, { fit: 'inside', withoutEnlargement: true });
          await base.clone().jpeg({ quality: 85 }).toFile(outImg);
          if (manual) {
            await sharp(path.join(dir, manual)).rotate().resize(MAX_SIDE, MAX_SIDE, { fit: 'inside', withoutEnlargement: true })
              .flatten({ background: '#d6d6d2' }).jpeg({ quality: 85 }).toFile(outClean);
          } else {
            const { data, info } = await base.clone().removeAlpha().raw().toBuffer({ resolveWithObject: true });
            const { rgb, erasedShare } = eraseBackground(data, info.width, info.height);
            await sharp(rgb, { raw: { width: info.width, height: info.height, channels: 3 } }).jpeg({ quality: 85 }).toFile(outClean);
            cleanOk = erasedShare > 0.4 && erasedShare < 0.995;
            if (!cleanOk) console.warn(`  ! ${group}/${file}: background erase looks off (${Math.round(erasedShare * 100)}% erased). Check clean/${id}.jpg or add ${stem}.clean.png`);
          }
        } catch (err) {
          console.warn(`  ! skipped ${group}/${file}: ${err.message}${/heic|heif/i.test(file) ? ' (convert HEIC to JPG first)' : ''}`);
          continue;
        }
      }
      photos.push({ id, group, img, clean, source: `${group}/${file}` });
    }
  }
  const count = (g) => photos.filter((p) => p.group === g).length;
  if (count('train') < 3 || count('heldout') < 1 || count('diverse') < 2) {
    throw new Error(`Need at least 3 train, 2 diverse, 1 heldout photos in photos-source/ (have ${count('train')}/${count('diverse')}/${count('heldout')}).`);
  }

  const override = path.join(PATHS.source, 'tier2.json');
  const pick = (g, k) => photos.filter((p) => p.group === g).slice(0, k).map((p) => p.id);
  const tier2 = fs.existsSync(override)
    ? JSON.parse(fs.readFileSync(override, 'utf8'))
    : { train: pick('train', 5), diverse: pick('diverse', 4), heldout: pick('heldout', 2) };

  const m = {
    objectType: OBJECT_TYPE,
    placeholders: photos.some((p) => p.source.includes('placeholder-')),
    photos, tier2,
  };
  fs.writeFileSync(path.join(PATHS.photos, 'manifest.json'), JSON.stringify(m, null, 2));
  console.log(`Photos ready: ${count('train')} train, ${count('diverse')} more-variety, ${count('heldout')} held-out.`);
  return m;
}

async function preAnalyzeTier2(m) {
  const { analyzeSet, testPhoto } = await import('./lib/lessonApi.js');
  const { train, diverse, heldout } = m.tier2;
  const out = {
    mock: mode() === 'mock', model: mode() === 'mock' ? null : CONFIG.model,
    createdAt: new Date().toISOString(), objectType: m.objectType, analyses: {}, tests: {},
  };
  // Tier 2 has a fixed set, so every reachable state is {clean?} x {more variety?}.
  for (const clean of [false, true]) {
    for (const div of [false, true]) {
      const state = { clean, diverse: div };
      const ids = div ? [...train, ...diverse] : [...train];
      console.log(`Analyzing Tier 2 set: ${stateKey(state)}`);
      const a = await analyzeSet({ objectType: m.objectType, ids, clean });
      out.analyses[stateKey(state)] = a;
      const rule = ruleFrom(a);
      for (const id of [...train, ...heldout]) {
        out.tests[testKey(state, id)] = await testPhoto({ objectType: m.objectType, id, clean, rule });
      }
    }
  }
  fs.writeFileSync(path.join(PATHS.photos, 'analysis.json'), JSON.stringify(out, null, 2));
  console.log(`Tier 2 pool pre-analyzed${out.mock ? ' (SIMULATED, mock mode)' : ` with ${CONFIG.model}`}.`);
}

try {
  const m = await prepareImages();
  if (!args.has('--images-only')) {
    if (args.has('--mock')) CONFIG.mock = true;
    if (mode() === 'no-key') throw new Error('Pre-analysis needs ANTHROPIC_API_KEY in .env (or use `npm run prep:mock` to rehearse).');
    await preAnalyzeTier2(m);
  }
} catch (err) {
  console.error(`prep failed: ${err.message}`);
  process.exit(1);
}
