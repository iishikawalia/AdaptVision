import express from 'express';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { exec } from 'node:child_process';
import { CONFIG, PATHS, mode } from './lib/config.js';
import { analyzeSet, testPhoto } from './lib/lessonApi.js';
import { manifest } from './lib/photos.js';
import { usage } from './lib/usage.js';
import { MIN_TRAIN, OBJECTS } from '../client/src/shared/lesson.js';

const app = express();
app.use(express.json({ limit: '50kb' })); // requests carry photo ids, never image bytes

function lanUrls() {
  return Object.values(os.networkInterfaces()).flat()
    .filter((i) => i && i.family === 'IPv4' && !i.internal)
    .map((i) => `http://${i.address}:${CONFIG.port}`);
}

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, mode: mode(), model: CONFIG.model, joinUrls: CONFIG.host === '0.0.0.0' ? lanUrls() : [] });
});
app.get('/api/usage', (_req, res) => res.json(usage()));

// Messages the room sees. Details stay in the facilitator's terminal.
function fail(res, err, where) {
  console.error(`[${where}]`, err.message);
  const status = err.status || 502;
  const msg = status === 401 ? 'The server\'s API key was rejected. Facilitator: check .env.'
    : status === 429 || status === 529 ? 'Matty is busy with the rest of the room. Try again in a moment.'
    : status === 503 || status === 400 ? err.message
    : 'Matty could not finish studying. Try again, or switch to the classroom set.';
  res.status(status).json({ error: msg });
}

function checkObject(objectType) {
  if (!OBJECTS[objectType]?.ready) throw Object.assign(new Error(`Unsupported object: ${objectType}`), { status: 400 });
  if (manifest().objectType !== objectType) throw Object.assign(new Error('Photo pool is for a different object'), { status: 400 });
}

app.post('/api/analyze', async (req, res) => {
  const { objectType = 'pen', ids, clean = false } = req.body || {};
  try {
    checkObject(objectType);
    if (!Array.isArray(ids) || ids.length < MIN_TRAIN || ids.length > 24 || new Set(ids).size !== ids.length) {
      return res.status(400).json({ error: `Send between ${MIN_TRAIN} and 24 different photo ids.` });
    }
    res.json(await analyzeSet({ objectType, ids, clean: !!clean }));
  } catch (err) {
    fail(res, err, 'analyze');
  }
});

app.post('/api/test', async (req, res) => {
  const { objectType = 'pen', id, clean = false, rule } = req.body || {};
  try {
    checkObject(objectType);
    if (typeof id !== 'string' || !rule || !['shortcut', 'object'].includes(rule.kind)) {
      return res.status(400).json({ error: 'Need a photo id and Matty\'s rule.' });
    }
    res.json(await testPhoto({ objectType, id, clean: !!clean, rule }));
  } catch (err) {
    fail(res, err, 'test');
  }
});

// Photos are served from the live folder so re-running prep never needs a rebuild.
app.use('/photos', express.static(PATHS.photos, { maxAge: '1h' }));

if (fs.existsSync(path.join(PATHS.dist, 'index.html'))) {
  app.use(express.static(PATHS.dist));
  app.get(/^(?!\/api\/).*/, (_req, res) => res.sendFile(path.join(PATHS.dist, 'index.html')));
}

app.listen(CONFIG.port, CONFIG.host, () => {
  const local = `http://localhost:${CONFIG.port}`;
  console.log(`\nAdaptVision is running: ${local}`);
  const lan = lanUrls();
  if (CONFIG.host === '0.0.0.0' && lan.length) console.log(`Participants join at: ${lan.join('  or  ')}`);
  console.log(`Mode: ${mode()}  |  model: ${CONFIG.model}`);
  if (mode() === 'no-key') console.log('Tier 1 needs ANTHROPIC_API_KEY in .env. Tier 2 still works.');
  if (mode() === 'mock') console.log('MOCK=1: no real analysis is happening. Rehearsal only.');
  if (process.argv.includes('--open') && process.env.OPEN_BROWSER !== '0') {
    const cmd = process.platform === 'darwin' ? 'open' : process.platform === 'win32' ? 'start ""' : 'xdg-open';
    exec(`${cmd} ${local}`, () => {});
  }
});
