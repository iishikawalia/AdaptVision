# Student Handout — Was Matty Really Learning?

**Name:** ________________________

1. What rule did Matty announce? ______________________________________

2. When we showed the surprise pen, what happened?
   ☐ Matty got it right   ☐ Matty got it WRONG

3. What was Matty *actually* paying attention to (instead of the pen)?
   _______________________________________________________________

4. Two ways we helped Matty learn better:
   - ____________________________________________________________
   - ____________________________________________________________

5. Why isn't it fair to test Matty on a photo it already studied?
   _______________________________________________________________

**Big idea:** A computer can be right for the *wrong reason*. This is called a
**spurious correlation** — the model learns something that happens to go along with
the answer (like a background colour) instead of the real thing.
