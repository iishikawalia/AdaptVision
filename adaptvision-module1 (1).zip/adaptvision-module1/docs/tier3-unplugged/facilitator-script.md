# Tier 3 (Unplugged) — Facilitator Script

No devices. The teacher role-plays **Matty**, and the class walks the same lesson on
paper. ~25–35 min. Prepare the photo set first (see `photo-set-guide.md`).

## Setup
- Print the **Training set**: 5–6 pens that all share one obvious incidental feature
  (all on the same blue paper, OR all with caps on). Keep it consistent — that shared
  feature is the trap.
- Print the **Reveal card**: one pen that breaks the pattern (no cap / white background).
- Print 1–2 **Held-out** pens (never shown during "training").

## Run

**1–2. Collect & Train.** Hold up the training pens one at a time: "These are all pens.
Matty is studying them." Act like you're memorizing.

**3. Declare.** In your best confident-robot voice, announce the rule the photos *actually*
share — e.g. *"Aha! If it's on blue paper, it's a pen! Blue = pen!"* (State whatever the
prepared set shares.)

**4. Discuss.** Ask: *"Is Matty really learning what a pen is — or did Matty just get lucky?"*
Take a few answers. Don't confirm yet.

**5. Reveal.** Show the Reveal card (pen that breaks the rule). Play confused as Matty:
*"That's on WHITE… so it's not a pen?? But… it clearly is 😳."* Let the class catch the mistake.
Name it: **Matty learned the background, not the pen.** (This is a *spurious correlation*.)

**6. Fix — better data.** "How do we help Matty?" Guide them to: *show pens on lots of
different backgrounds.* Add varied pens to the set; re-declare a better rule.

**7. Fix — ignore the distraction.** Cover the backgrounds (a paper frame around each pen)
so only the pen shows. "Now Matty can't cheat off the background."

**8. Retrain.** Re-study the improved set; Matty states a rule that's actually about pens.

**9–10. Test & Leakage.** Hold up a pen Matty *already studied* and let Matty ace it.
Ask: *"Is that a fair test — Matty already saw that exact photo?"* Introduce **leakage:**
testing on something you trained on isn't a real test.

**11. Fair test.** Show a **held-out** pen Matty never saw. *Now* see if the rule holds.
Discuss why a fair test uses new examples.

## One-line takeaway for the board
> A model can look smart for the wrong reason. Give it varied examples, hide the
> distractions, and always test it on something new.
