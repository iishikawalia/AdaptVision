# Tier 3 — Photo Set Prep Guide

Print in colour, one item per card (index-card size is fine).

## Training set (5–6 cards) — MUST share one incidental feature
Pick **one** trap and keep it consistent across every training card:
- **Background trap:** every pen photographed on the same blue paper, OR
- **Cap trap:** every pen has its cap on, OR
- **Angle/hand trap:** every pen held the same way.

## Reveal card (1) — breaks the trap
A clearly-a-pen photo that violates the chosen feature: a pen on **white** (background
trap) or a pen with **no cap** (cap trap).

## Diversify set (3–4) — for the "fix" step
Pens on many different backgrounds / with and without caps — the opposite of consistent.

## Held-out cards (1–2) — never shown during training
Fresh pens for the fair-test step (step 11).

## Optional
A few **non-pen** objects that share the trap (a blue eraser, if using the background
trap) to push the discussion: "Matty might call THIS a pen too!"
