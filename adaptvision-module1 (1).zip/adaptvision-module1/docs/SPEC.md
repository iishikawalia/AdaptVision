# Module 1 — "Meet Matty" (Spurious Correlations) — Spec (condensed)

Full app spec lives in the design doc; this is the build-facing summary for this repo.

## Idea
Middle schoolers (11–14) submit pictures of pens. A vision model (Claude) finds a
**shared incidental feature** across them (e.g. "blue background"). Matty states that as
a confident **but wrong** rule. Students diagnose the mistake and fix it with (a) more
diverse data and (b) background removal, then learn about **train/test leakage**.

Students never train a model themselves — "training" is one submit action; the real work
is a Claude vision call behind the scenes (`server/`).

## What's real vs scripted
- **Real:** the feature detection (`/api/analyze`) and the held-out test (`/api/test-heldout`).
- **Real:** the leakage test too (the rule is applied to a studied photo).
- **Description only:** the counterexample is a generated sentence shown via Matty.

## Flow (state machine): see client/src/Lesson.jsx
1 Collect · 2 Train · 3 Declare · 4 Discuss · 5 Reveal · 6 Fix (diverse data) ·
7 Fix (background removal) · 8 Retrain · 9 Test · 10 Leakage reveal · 11 Fair test

## Tiers
- **Tier 1 (Live):** pairs choose from provided photos; every analysis is a live call.
- **Tier 2 (Classroom set):** fixed preloaded pool, pre-analyzed by `npm run prep`; no calls in class.
- **Tier 3 (Unplugged):** teacher-led role-play, no software — see `docs/tier3-unplugged/`.

## Status in this repo
All 11 steps are implemented for Tiers 1 and 2. Steps 6 and 7 are chosen adaptively
(preprocessing for background shortcuts, variety for object shortcuts) and can run
as two rounds. The leakage test and fair test are both real checks. Seed-bank
blending was dropped: with provided, curated photos a pattern reliably exists.

## Parameterization
Object type is `pen` for the pilot but not hardcoded: see `client/src/shared/lesson.js`
(`OBJECTS`), `server/prep.js` (`OBJECT_TYPE`) and `server/lib/prompts.js`. Add `eraser` later without code surgery.
